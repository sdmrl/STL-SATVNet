import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from statsmodels.tsa.seasonal import STL

# 输入数据
data = []

index = pd.date_range(start='1960-01-01', periods=len(data), freq='M')
ts_data = pd.Series(data, index=index)
stl = STL(ts_data, seasonal=13)
result = stl.fit()

seasonal = result.seasonal
trend = result.trend
residual = result.resid

trend_array = trend.to_numpy()
seasonal_array = seasonal.to_numpy()
residual_array = residual.to_numpy()

with open('trend_data.txt', 'w') as f:
    for value in trend_array:
        f.write(f"{value},\n")

with open('seasonal_data.txt', 'w') as f:
    for value in seasonal_array:
        f.write(f"{value},\n")

with open('residual_data.txt', 'w') as f:
    for value in residual_array:
        f.write(f"{value},\n")
