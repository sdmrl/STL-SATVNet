"""
A training function for SATVNN.

"""

import numpy as np
import torch
import time
from dataHelpers import format_input

import torch.nn.functional as F
plot_train_progress = False
if plot_train_progress:
    import matplotlib.pyplot as plt

def train(SA, train_x, train_y, validation_x=None, validation_y=None, restore_session=False):

    if type(train_x) is np.ndarray:
        train_x = torch.from_numpy(train_x).type(torch.FloatTensor)
    if type(train_y) is np.ndarray:
        train_y = torch.from_numpy(train_y).type(torch.FloatTensor)
    if type(validation_x) is np.ndarray:
        validation_x = torch.from_numpy(validation_x).type(torch.FloatTensor)
    if type(validation_y) is np.ndarray:
        validation_y = torch.from_numpy(validation_y).type(torch.FloatTensor)

    train_x = format_input(train_x)
    validation_x = format_input(validation_x)

    validation_x = validation_x.to(SA.device)
    validation_y = validation_y.to(SA.device)

    if restore_session:
        # Load model parameters
        checkpoint = torch.load(SA.save_file)
        SA.model.load_state_dict(checkpoint['model_state_dict'])
        SA.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])

    n_samples = train_x.shape[0]

    training_costs = []
    validation_costs = []

    SA.model.train()

    train_window = 3 * SA.period
    predict_start = 2 * SA.period

    for epoch in range(SA.n_epochs):

        t_start = time.time()

        print('Epoch: %i of %i' % (epoch + 1, SA.n_epochs))

        batch_cost = []

        count = 0

        permutation = np.random.permutation(np.arange(0, n_samples, SA.batch_size))

        for sample in permutation:

            input = train_x[sample:sample + SA.batch_size, :]
            target = train_y[:, sample:sample + SA.batch_size, :]

            input = input.to(SA.device)
            target = target.to(SA.device)

            SA.optimizer.zero_grad()

            outputs = SA.model(input=input, target=target,
                                    is_training=True)
            loss = F.mse_loss(input=outputs, target=target)
            batch_cost.append(loss.item())

            loss.backward()

            SA.optimizer.step()


        epoch_cost = np.mean(batch_cost)

        training_costs.append(epoch_cost)

        if plot_train_progress:
            plt.cla()
            plt.plot(np.arange(input.shape[0], input.shape[0] + target.shape[0]), target[:, 0, 0])
            temp = outputs.detach()
            plt.plot(np.arange(input.shape[0], input.shape[0] + target.shape[0]), temp[:, 0, 0])
            plt.pause(0.1)

        if validation_x is not None:
            SA.model.eval()
            with torch.no_grad():
                y_valid = SA.model(validation_x, validation_y,
                                        is_training=False)
                loss = F.mse_loss(input=y_valid, target=validation_y)  #

                validation_costs.append(loss.item())
            SA.model.train()

        print("Average epoch training cost: ", epoch_cost)
        if validation_x is not None:
            print('Average validation cost:     ', validation_costs[-1])
        print("Epoch time:                   %f seconds" % (time.time() - t_start))
        print("Estimated time to complete:   %.2f minutes, (%.2f seconds)" %
              ((SA.n_epochs - epoch - 1) * (time.time() - t_start) / 60,
               (SA.n_epochs - epoch - 1) * (time.time() - t_start)))

        # Save a model checkpoint
        best_result = False
        if validation_x is None:
            if training_costs[-1] == min(training_costs):
                best_result = True
        else:
            if validation_costs[-1] == min(validation_costs):
                best_result = True
        if best_result:
            torch.save({
                'model_state_dict': SA.model.state_dict(),
                'optimizer_state_dict': SA.optimizer.state_dict(),
            }, SA.save_file)
            print("Model saved in path: %s" % SA.save_file)
    return training_costs,  validation_costs
