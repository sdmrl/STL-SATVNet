import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# 使用您提供的数据
data = []

data = np.array(data).reshape(-1, 1)

scaler = MinMaxScaler()
data_scaled = scaler.fit_transform(data)
def create_dataset(data, time_step=1):
    X, y = [], []
    for i in range(len(data) - time_step):
        X.append(data[i:(i + time_step), 0])
        y.append(data[i + time_step, 0])
    return np.array(X), np.array(y)

time_step = 12
X, y = create_dataset(data_scaled, time_step)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2,shuffle=False)
model = Sequential()
model.add(Dense(units=16, activation='relu', input_dim=time_step))
model.add(Dense(units=8,activation='relu'))
model.add(Dense(units=1))

model.compile(optimizer='adam', loss='mean_squared_error')

model.fit(X_train, y_train, epochs=100, batch_size=16, verbose=1)

y_pred = model.predict(X_test)

y_test_inv = scaler.inverse_transform(y_test.reshape(-1, 1))
y_pred_inv = scaler.inverse_transform(y_pred.reshape(-1, 1))

idx_file = 'idx.txt'
with open(idx_file, 'r') as f:
    idx1 = int(f.readline().strip())
    idx2 = int(f.readline().strip())
def find_element_in_file(y_true_series, file_path):
    if isinstance(y_true_series, np.ndarray):
        y_true_series = y_true_series.tolist()
    last_element = y_true_series[0][0]
    with open(file_path, 'r') as file:
        lines = file.readlines()
    for index, line in enumerate(lines):
        element = float(line.strip())
        if abs(element-last_element) <1e-7:
            return index, element

    return None, None

file_path = 'search sequence/search2.txt'
index, element = find_element_in_file(y_test_inv, file_path)
sta = idx1-index
en = sta+idx2-idx1
sliced_series = y_pred_inv[sta:en+1]
with open('result sequence/result2.txt', 'w') as f:
    for value in sliced_series:
        f.write(f"{value[0]}\n")
