from dataHelpers import generate_data
import numpy as np
import matplotlib.pyplot as plt
from SATVNN import SATVNN
from evaluate import evaluate
from train import train

np.random.seed(1)
data = np.array([])

train_x, train_y, test_x, test_y, valid_x, valid_y, period,mm = generate_data(data,period = 12)


in_seq_length = 2 * period
out_seq_length = period
hidden_dim =75
head = 1
M = 2
input_dim = 1
output_dim = 1
learning_rate = 0.001
batch_size = 16
dis_alpha = 0.1
d_model = 70

SA = SATVNN(in_seq_length=in_seq_length, out_seq_length=out_seq_length, d_model=d_model,input_dim=input_dim,
                        hidden_dim=hidden_dim, h=head, M=M, output_dim=output_dim, batch_size = batch_size,
                        period=period, n_epochs = 1, learning_rate = learning_rate, train_x=train_x, save_file = './satvnn.pt')


training_costs, validation_costs = train(SA, train_x, train_y, valid_x, valid_y, restore_session=False)

predict_start = 24
import numpy as np

y_pred = SA.forecast(test_x, predict_start)
y_pred_inverse = np.zeros_like(y_pred)
y_true_inverse = np.zeros_like(test_y)

for i in range(y_pred.shape[0]):
    y_pred_sample = y_pred[i, :, :]
    y_pred_inverse[i, :, :] = mm.inverse_transform(y_pred_sample)

for i in range(test_y.shape[0]):
    test_y_sample = test_y[i, :, :]
    y_true_inverse[i, :, :] = mm.inverse_transform(test_y_sample)
y_pred_series = y_pred_inverse[-1, :, 0]
y_true_series = y_true_inverse[-1, :, 0]

time_steps = np.arange(test_x.shape[1] + y_pred.shape[1])

def find_element_in_file(y_true_series, file_path):
    if isinstance(y_true_series, np.ndarray):
        y_true_series = y_true_series.tolist()

    last_element = y_true_series[-1]
    with open(file_path, 'r') as file:
        lines = file.readlines()

    for index, line in enumerate(lines):
        element = float(line.strip())
        if abs(element-last_element) <1e-7:
            return index, element
    return None, None

file_path = 'search sequence/search1.txt'
index, element = find_element_in_file(y_true_series, file_path)
en=index;
sta=index-y_true_series.size+1
with open('idx.txt', 'w') as f:
    f.write(f"{sta}\n")
    f.write(f"{en}\n")
with open('result sequence/result1.txt', 'w') as f:
    for value in y_pred_series:
        f.write(f"{value}\n")
with open('data/Champagne sales.txt', 'r') as file:
    data1 = file.readlines()
data_list = [float(line.strip()) for line in data1]
cut_data = data_list[sta:en+1]
with open('search sequence/search4.txt', 'w') as f:
    for value in cut_data:
        f.write(f"{value}\n")
time_steps = np.arange(test_x.shape[1] + y_pred.shape[1])
start_index = 262
end_index = 276
true_values = data[start_index:end_index + 1]
pred_values = y_pred_series[start_index - (len(data) - len(y_pred_series)):end_index + 1 - (len(data) - len(y_pred_series))]
