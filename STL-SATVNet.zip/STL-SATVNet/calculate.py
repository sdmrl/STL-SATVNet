import numpy as np
from matplotlib import pyplot as plt
def calculate_mase(y_true, y_pred):

    mae = np.mean(np.abs(y_true - y_pred))

    naive_forecast_error = np.mean(np.abs(np.diff(y_true)))

    mase = mae / naive_forecast_error
    return mase


def calculate_smape(y_true, y_pred):
    n = len(y_true)
    smape = 0
    for i in range(n):
        smape += abs(y_true[i] - y_pred[i]) / ((abs(y_true[i]) + abs(y_pred[i])) / 2)
    smape = smape *100/ n
    return smape


y_pred = []
y_true = []

with open('result sequence/result1.txt', 'r') as f1, open('result sequence/result2.txt', 'r') as f2,open('result sequence/result3.txt', 'r') as f3:
    lines1 = f1.readlines()
    lines2 = f2.readlines()
    lines3 = f3.readlines()

for line1, line2,line3 in zip(lines1, lines2,lines3):
    value1 = float(line1.strip())
    value2 = float(line2.strip())
    value3 = float(line3.strip())
    y_pred.append(value3+value2+value1)

with open('search sequence/search4.txt', 'r') as f:
    lines = f.readlines()
    y_true = [float(line.strip()) for line in lines]
smape_value = calculate_smape(y_true, y_pred)
y_true = np.array(y_true)
y_pred = np.array(y_pred)
mase_value = calculate_mase(y_true, y_pred)


print(f"MASE: {mase_value}")
print(f"SMAPE: {smape_value}")

