import numpy as np
import pandas as pd
from statsmodels.tsa.statespace.sarimax import SARIMAX
import matplotlib.pyplot as plt
from itertools import product
data = []
series = pd.Series(data)
if series.isnull().any():
    series = series.fillna(series.mean())

split_ratio = 0.8
split_index = int(len(series) * split_ratio)
train, test = series[0:split_index], series[split_index:]
p_range = range(0, 3)
d_range = range(0, 3)
q_range = range(0, 3)
P_range = range(0, 3)
D_range = range(0, 2)
Q_range = range(0, 2)
s_range = [12]

param_combinations = list(product(p_range, d_range, q_range, P_range, D_range, Q_range, s_range))

best_aic = float('inf')
best_params = None

for params in param_combinations:
    p, d, q, P, D, Q, s = params
    try:
        model = SARIMAX(train, order=(p, d, q), seasonal_order=(P, D, Q, s))
        results = model.fit(disp=False)
        aic = results.aic
        if aic < best_aic:
            best_aic = aic
            best_params = params
    except Exception as e:
        continue

model = SARIMAX(train, order=best_params[:3], seasonal_order=best_params[3:])
results = model.fit(disp=False)

predictions = results.get_prediction(start=split_index, end=len(series) - 1)
predicted_mean = predictions.predicted_mean

predicted_values_array = predicted_mean.to_numpy()
pre_list_of_lists = [[element] for element in predicted_values_array]

test_values_array = test.to_numpy()
test_list_of_lists = [[element] for element in test_values_array]

idx_file = 'idx.txt'
with open(idx_file, 'r') as f:
    idx1 = int(f.readline().strip())
    idx2 = int(f.readline().strip())

idx1 = min(idx1, len(series) - 1)
idx2 = min(idx2, len(series))

def find_element_in_file(y_true_series, file_path):
    if isinstance(y_true_series, np.ndarray):
        y_true_series = y_true_series.tolist()

    last_element = y_true_series[0][0]
    print(last_element)

    with open(file_path, 'r') as file:
        lines = file.readlines()

    for index, line in enumerate(lines):
        element = float(line.strip())
        if abs(element - last_element) < 1e-8:
            return index, element

    return None, None

file_path = 'search sequence/search3.txt'
index, element = find_element_in_file(test_list_of_lists, file_path)

sta = idx1 - index
en = sta + idx2 - idx1
sliced_series = pre_list_of_lists[sta:en + 1]

with open('result sequence/result3.txt', 'w') as f:
    for value in sliced_series:
        f.write(f"{value[0]}\n")
