import torch
def mse_loss(input, target):
    mse = torch.mean((input - target) ** 2)
    return mse