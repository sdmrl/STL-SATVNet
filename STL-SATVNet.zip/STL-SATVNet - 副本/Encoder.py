import torch
import torch.nn as nn
import numpy as np
from typing import Optional
import torch.nn.functional as F


beta = 1 / 5
class Self_attention_layer(nn.Module):
    def __init__(self,
                 d_model: int,
                 q: int,
                 v: int,
                 h: int,
                 attention_size: int = None):
        super().__init__()
        self._dopout = nn.Dropout(p=0.3)
        self._h = h

        self._W_q = nn.Linear(d_model, q * self._h)
        self._W_k = nn.Linear(d_model, q * self._h)
        self._W_v = nn.Linear(d_model, v * self._h)

        self._W_o = nn.Linear(self._h * v, d_model)

        self._scores = None

    def forward(self,
                query: torch.Tensor,
                key: torch.Tensor,
                value: torch.Tensor,
                mask: Optional[str] = None) -> torch.Tensor:
        K = query.shape[1]


        queries = torch.cat(self._W_q(query).chunk(self._h, dim=-1), dim=0)
        keys = torch.cat(self._W_k(key).chunk(self._h, dim=-1), dim=0)  #
        values = torch.cat(self._W_v(value).chunk(self._h, dim=-1), dim=0)


        self._scores = torch.bmm(query, key.transpose(1, 2)) / np.sqrt(K)
        # dist_mask_tile = get_dist_mask_tile(self._scores.shape[1])
        # self._scores += dist_mask_tile.cuda()
        dir_mask = torch.triu(torch.ones((self._scores.shape[1], self._scores.shape[1])), diagonal=1).bool().cuda()
        self._scores = self._scores.masked_fill(dir_mask, float('-inf')).cuda()

        if mask == "subsequent":
            future_mask = torch.triu(torch.ones((K, K)), diagonal=1).bool()
            future_mask = future_mask.to(self._scores.device)
            self._scores = self._scores.masked_fill(future_mask, float('-inf'))
        self._scores = F.softmax(self._scores, dim=-1)
        attention = torch.bmm(self._scores, value)
        return attention

    @property
    def attention_map(self) -> torch.Tensor:
        if self._scores is None:
            raise RuntimeError(
                "Evaluate the model once to generate attention map")
        return self._scores


class PositionwiseFeedForward(nn.Module):
    """A two-feed-forward-layer module """

    def __init__(self,
                 d_model: int,
                 d_ff: Optional[int] = 210):
        super().__init__()
        self._linear1 = nn.Linear(d_model, d_ff)
        self._linear2 = nn.Linear(d_ff, d_model)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self._linear2(F.relu(self._linear1(x)))


class Encoder(nn.Module):
    """Encoder layer is made up of self-attn layer and feed forward and layerNorm (defined below)"""

    def __init__(self,
                 d_model: int,
                 q: int,
                 v: int,
                 h: int,
                 attention_size: int = None,
                 dropout: float = 0.3,
                 chunk_mode: str = 'chunk'):
        super().__init__()
        self._selfAttention = Self_attention_layer(d_model, q, v, h, attention_size=attention_size)
        self._feedForward = PositionwiseFeedForward(d_model)

        self._layerNorm1 = nn.LayerNorm(d_model)
        self._layerNorm2 = nn.LayerNorm(d_model)

        self._dopout = nn.Dropout(p=dropout)

        # 初始化dct层
        # self.dct_layer = cxd_dctnet.dct_channel_block(d_model)
        # self.dct_norm = nn.LayerNorm([d_model])  # 调整normalized_shape参数

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # mid  = self.dct_layer(x)
        # x = x+mid

        # each encoder layer
        residual = x
        x = self._selfAttention(query=x, key=x, value=x)  # Cauchy self-attention layer
        x = self._dopout(x)
        x = self._layerNorm1(x + residual)
        # Feed forward
        residual = x
        x = self._feedForward(x)
        x = self._dopout(x)
        x = self._layerNorm2(x + residual)

        # y=x;
        # z=x;
        # if torch.equal(z, y):
        #     print("wyxwwwwwww")

        return x

    @property
    def attention_map(self) -> torch.Tensor:
        return self._selfAttention.attention_map
