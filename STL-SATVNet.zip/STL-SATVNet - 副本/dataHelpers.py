import numpy as np
from sklearn.preprocessing import MinMaxScaler
import torch

def batch_format(dataset, T_in_seq, T_out_seq, time_major=True):

    T, n_dims = dataset.shape
    inputs = []
    targets = []
    for t in range(T - T_in_seq - T_out_seq + 1):
        inputs.append(dataset[t:t + T_in_seq, :])
        targets.append(dataset[t + T_in_seq:t + T_in_seq + T_out_seq, :])
    inputs = np.array(inputs)
    targets = np.array(targets)

    if time_major:
        inputs = np.transpose(inputs, (1, 0, 2))
        targets = np.transpose(targets, (1, 0, 2))

    return inputs, targets
def generate_data(data,period):
    T_in_seq = 2 * period
    T_out_seq = period
    dataset=data.reshape(-1,1)
    n_samples = len(dataset) - T_in_seq - T_out_seq + 1
    test_idx = n_samples - int(0.2 * n_samples)
    valid_idx = n_samples - int(0.1 * n_samples)
    mm = MinMaxScaler()
    dataset = mm.fit_transform(dataset)
    inputs, targets = batch_format(dataset, T_in_seq, T_out_seq, time_major=True)
    train_x = inputs[:, :test_idx, :]
    train_y = targets[:, :test_idx, :]
    print(train_y.size)
    test_x = inputs[:, test_idx:valid_idx, :]
    test_y = targets[:, test_idx:valid_idx, :]
    valid_x = inputs[:, valid_idx:, :]
    valid_y = targets[:, valid_idx:, :]
    return train_x, train_y, test_x, test_y, valid_x, valid_y, period, mm


def format_input(input):
    in_seq_length, batch_size, input_dim = input.shape
    input_reshaped = input.permute(1, 0, 2)
    input_reshaped = torch.reshape(input_reshaped, (batch_size, -1))
    return input_reshaped
